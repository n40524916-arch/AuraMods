#pragma once
#include "imgui.h"

void ApplyPurpleTheme();