#pragma once

#include <imgui.h>

namespace touch {

enum class Action : int {
    Down = 0,
    Up = 1,
    Move = 2,
};

struct Event {
    Action action = Action::Up;
    float x = 0.0f;
    float y = 0.0f;
    int pointers = 0;
    float y_velocity = 0.0f;
    float x_velocity = 0.0f;
};

void HandleMotionEvent(int action, float x, float y, int pointers);
void ApplyLastEventToImGui();
const Event &GetLastEvent();

void SetCaptureInput(bool capture);
bool IsCapturingInput();

void DumpInputRelatedMaps();
bool InstallHooks();
bool IsHookInstalled();

} // namespace touch
