#include "imgui_touch.hpp"

#include <android/input.h>
#include <android/log.h>
#include <dlfcn.h>
#include <unistd.h>
#include <atomic>
#include <cstdio>
#include <cstring>

#include "And64InlineHook/And64InlineHook.hpp"
#include "imgui_impl_android.h"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "CubixDLC", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "CubixDLC", __VA_ARGS__)



namespace touch {

using InputConsumeFn = int32_t (*)(void *, void *, bool, long, uint32_t *, void **);
using InitMotionFn = void (*)(void *, void *, void *);

static Event g_last_event;
static InputConsumeFn g_orig_consume = nullptr;
static InitMotionFn g_orig_init_motion = nullptr;
static std::atomic_bool g_capture_input{false};

static const char *kConsumeSymbol =
    "_ZN7android13InputConsumer7consumeEPNS_26InputEventFactoryInterfaceEblPjPPNS_10InputEventE";
static const char *kInitMotionSymbol =
    "_ZN7android13InputConsumer21initializeMotionEventEPNS_11MotionEventEPKNS_12InputMessageE";

void HandleMotionEvent(int action, float x, float y, int pointers) {
    // (оставляем для совместимости, но теперь всё делает ImGui_ImplAndroid)
    g_last_event.action = static_cast<Action>(action);
    g_last_event.x = x;
    g_last_event.y = y;
    g_last_event.pointers = pointers;
    g_last_event.y_velocity = 0.0f;
    g_last_event.x_velocity = 0.0f;
}

void ApplyLastEventToImGui() {}
const Event &GetLastEvent() { return g_last_event; }
void SetCaptureInput(bool capture) { g_capture_input = capture; }
bool IsCapturingInput() { return g_capture_input; }

void DumpInputRelatedMaps() {
    // (можно оставить для отладки)
}

// Поиск символа
static void* FindSymbol(const char* name) {
    void* sym = dlsym(RTLD_DEFAULT, name);
    if (sym) return sym;

    const char* libs[] = {"libinput.so", "libandroid.so", "libinputflinger.so"};
    for (auto lib : libs) {
        void* handle = dlopen(lib, RTLD_NOW | RTLD_LOCAL);
        if (handle) {
            sym = dlsym(handle, name);
            dlclose(handle);
            if (sym) return sym;
        }
    }
    return nullptr;
}

// Хук на initializeMotionEvent
static void HookInitMotionEvent(void *thiz, void *motionEvent, void *msg) {
    if (g_orig_init_motion) g_orig_init_motion(thiz, motionEvent, msg);
    if (!motionEvent) return;
    AInputEvent* ev = (AInputEvent*)motionEvent;
    if (AInputEvent_getType(ev) == AINPUT_EVENT_TYPE_MOTION) {
        ImGui_ImplAndroid_HandleInputEvent(ev);
        static int cnt = 0;
        if (++cnt % 30 == 0) {
            int32_t act = AMotionEvent_getAction(ev) & AMOTION_EVENT_ACTION_MASK;
            float x = AMotionEvent_getX(ev, 0);
            float y = AMotionEvent_getY(ev, 0);
            LOGI("initMotion: act=%d x=%.1f y=%.1f", act, x, y);
        }
    }
}

// Хук на consume
static int32_t HookConsume(void *thiz, void *factory, bool batches, long time, uint32_t* seq, void** outEvent) {
    int32_t res = 0;
    if (g_orig_consume) res = g_orig_consume(thiz, factory, batches, time, seq, outEvent);
    if (res == 0 && outEvent && *outEvent) {
        AInputEvent* ev = (AInputEvent*)*outEvent;
        if (AInputEvent_getType(ev) == AINPUT_EVENT_TYPE_MOTION) {
            ImGui_ImplAndroid_HandleInputEvent(ev);
            static int cnt = 0;
            if (++cnt % 30 == 0) {
                int32_t act = AMotionEvent_getAction(ev) & AMOTION_EVENT_ACTION_MASK;
                float x = AMotionEvent_getX(ev, 0);
                float y = AMotionEvent_getY(ev, 0);
                LOGI("consume: act=%d x=%.1f y=%.1f", act, x, y);
            }
        }
    }
    return res;
}

bool InstallHooks() {

    // Ищем символы
    void* sym_init = FindSymbol(kInitMotionSymbol);
    if (sym_init) {
        LOGI("Found initializeMotionEvent at %p", sym_init);
        A64HookFunction(sym_init, (void*)HookInitMotionEvent, (void**)&g_orig_init_motion);
        if (g_orig_init_motion) {
            LOGI("Hook on initializeMotionEvent installed");
            return true;
        }
        LOGE("A64HookFunction failed for initializeMotionEvent");
        g_orig_init_motion = nullptr;
    } else {
        LOGE("initializeMotionEvent symbol not found");
    }

    void* sym_consume = FindSymbol(kConsumeSymbol);
    if (sym_consume) {
        LOGI("Found consume at %p", sym_consume);
        A64HookFunction(sym_consume, (void*)HookConsume, (void**)&g_orig_consume);
        if (g_orig_consume) {
            LOGI("Hook on consume installed");
            return true;
        }
        LOGE("A64HookFunction failed for consume");
        g_orig_consume = nullptr;
    } else {
        LOGE("consume symbol not found");
    }

    LOGE("No hook installed — touch input may not work but continuing");
    return false;
}

bool IsHookInstalled() {
    return g_orig_init_motion != nullptr || g_orig_consume != nullptr;
}

} // namespace touch