#pragma once
#include "imgui.h"
#include <cstdio>

void DrawWatermark() {
    ImGuiIO& io  = ImGui::GetIO();
    int fps      = static_cast<int>(io.Framerate);

    ImDrawList* draw = ImGui::GetForegroundDrawList();

    
    const char* str_brand    = "UdawzCheats.t.me";
    const char* str_lifetime = "ssc";
    char        str_fps[16];
    snprintf(str_fps, sizeof(str_fps), "%d FPS", fps);

    
    float pos_x     = 20.0f;
    float pos_y     = 20.0f;
    float total_h   = 44.0f;  
    float icon_size = 28.0f;   
    float pad_x     = 12.0f;   
    float gap       = 12.0f;   
    float sep_pad   = 10.0f;   
    float round_cap = total_h * 0.5f; 
    float round_s   = 6.0f;           

    ImVec2 sz_brand    = ImGui::CalcTextSize(str_brand);
    ImVec2 sz_lifetime = ImGui::CalcTextSize(str_lifetime);
    ImVec2 sz_fps      = ImGui::CalcTextSize(str_fps);
    ImVec2 sz_S        = ImGui::CalcTextSize("S");

    
    float total_w = pad_x                              
                  + icon_size + gap                    
                  + sz_brand.x + gap                  
                  + 1.0f + gap                      
                  + sz_lifetime.x + gap               
                  + 1.0f + gap                        
                  + sz_fps.x + pad_x;                 

    ImVec2 min_p = ImVec2(pos_x, pos_y);
    ImVec2 max_p = ImVec2(pos_x + total_w, pos_y + total_h);

  
    ImU32 col_bg      = IM_COL32(28,  25,  23,  245);   
    ImU32 col_icon_bg = IM_COL32(195, 90,  35,  255);   
    ImU32 col_s_text  = IM_COL32(255, 255, 255, 255);   
    ImU32 col_brand   = IM_COL32(240, 235, 230, 255);   
    ImU32 col_muted   = IM_COL32(160, 150, 145, 255);  
    ImU32 col_sep     = IM_COL32(90,  85,  80,  200);   

  
    draw->AddRectFilled(min_p, max_p, col_bg, round_cap);

  
    float icon_x = pos_x + pad_x;
    float icon_y = pos_y + (total_h - icon_size) * 0.5f;
    draw->AddRectFilled(
        ImVec2(icon_x, icon_y),
        ImVec2(icon_x + icon_size, icon_y + icon_size),
        col_icon_bg, round_s
    );
    draw->AddText(
        ImVec2(icon_x + (icon_size - sz_S.x) * 0.5f,
               icon_y + (icon_size - sz_S.y) * 0.5f),
        col_s_text, "S"
    );

    float cur_x = icon_x + icon_size + gap;

    
    draw->AddText(
        ImVec2(cur_x, pos_y + (total_h - sz_brand.y) * 0.5f),
        col_brand, str_brand
    );
    cur_x += sz_brand.x + gap;

    
    draw->AddLine(
        ImVec2(cur_x, pos_y + sep_pad),
        ImVec2(cur_x, pos_y + total_h - sep_pad),
        col_sep, 1.5f
    );
    cur_x += 1.0f + gap;

    
    draw->AddText(
        ImVec2(cur_x, pos_y + (total_h - sz_lifetime.y) * 0.5f),
        col_muted, str_lifetime
    );
    cur_x += sz_lifetime.x + gap;

  
    draw->AddLine(
        ImVec2(cur_x, pos_y + sep_pad),
        ImVec2(cur_x, pos_y + total_h - sep_pad),
        col_sep, 1.5f
    );
    cur_x += 1.0f + gap;

   
    draw->AddText(
        ImVec2(cur_x, pos_y + (total_h - sz_fps.y) * 0.5f),
        col_muted, str_fps
    );
}
