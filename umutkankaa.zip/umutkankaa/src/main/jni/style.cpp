#include "style.h"

void ApplyPurpleTheme() {
    ImGuiStyle& style = ImGui::GetStyle();

    
    style.Colors[ImGuiCol_WindowBg]     = ImVec4(0.082f, 0.082f, 0.082f, 1.0f);
    style.Colors[ImGuiCol_ChildBg]      = ImVec4(0.098f, 0.098f, 0.098f, 1.0f);
    style.Colors[ImGuiCol_PopupBg]      = style.Colors[ImGuiCol_WindowBg];
    style.Colors[ImGuiCol_MenuBarBg]    = style.Colors[ImGuiCol_ChildBg];
    style.Colors[ImGuiCol_TitleBg]      = style.Colors[ImGuiCol_ChildBg];
    style.Colors[ImGuiCol_TitleBgActive]= style.Colors[ImGuiCol_ChildBg];

    style.Colors[ImGuiCol_ScrollbarBg]  = ImVec4(0,0,0,0);
    style.Colors[ImGuiCol_ScrollbarGrab]= ImVec4(0.098f,0.098f,0.098f,1.0f);
    style.Colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.098f,0.098f,0.098f,0.7f);
    style.Colors[ImGuiCol_ScrollbarGrabActive]  = ImVec4(0.098f,0.098f,0.098f,0.5f);

    style.Colors[ImGuiCol_FrameBg]      = ImVec4(0.082f,0.082f,0.082f,1.0f);
    style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.082f,0.082f,0.082f,0.7f);
    style.Colors[ImGuiCol_FrameBgActive]  = ImVec4(0.082f,0.082f,0.082f,0.5f);

    style.Colors[ImGuiCol_Button]       = ImVec4(0.082f,0.082f,0.082f,1.0f);
    style.Colors[ImGuiCol_ButtonHovered]= ImVec4(0.082f,0.082f,0.082f,0.7f);
    style.Colors[ImGuiCol_ButtonActive] = ImVec4(0.082f,0.082f,0.082f,0.5f);

    style.Colors[ImGuiCol_Header]       = ImVec4(0.098f,0.098f,0.098f,1.0f);
    style.Colors[ImGuiCol_HeaderHovered]= ImVec4(0.098f,0.098f,0.098f,0.7f);
    style.Colors[ImGuiCol_HeaderActive] = ImVec4(0.098f,0.098f,0.098f,0.5f);

    style.Colors[ImGuiCol_Border]       = ImVec4(0.122f,0.122f,0.122f,1.0f);
    style.Colors[ImGuiCol_Separator]    = style.Colors[ImGuiCol_Border];

    style.Colors[ImGuiCol_CheckMark]    = ImVec4(0.605f, 0.349f, 0.714f, 1.0f); // #9B59B6
    // Фиолетовый слайдер
    style.Colors[ImGuiCol_SliderGrab]   = ImVec4(0.605f, 0.349f, 0.714f, 1.0f);
    style.Colors[ImGuiCol_SliderGrabActive] = ImVec4(0.605f, 0.349f, 0.714f, 0.7f);

    style.Colors[ImGuiCol_Text]         = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
    style.Colors[ImGuiCol_TextDisabled] = ImVec4(0.38f, 0.38f, 0.38f, 1.0f);


    style.WindowRounding    = 3.0f;
    style.ChildRounding     = 2.0f;
    style.FrameRounding     = 2.0f;
    style.PopupRounding     = 2.0f;
    style.GrabRounding      = 2.0f;
    style.TabRounding       = 2.0f;
    style.ScrollbarRounding = 1.0f;

    style.ButtonTextAlign  = ImVec2(0.5f, 0.5f);
    style.WindowTitleAlign = ImVec2(0.5f, 0.5f);

    style.FramePadding     = ImVec2(8.0f, 8.0f);
    style.ItemSpacing      = ImVec2(14.0f, 14.0f);
    style.WindowPadding    = ImVec2(14.0f, 14.0f);
    style.ItemInnerSpacing = ImVec2(8.0f, 4.0f);

    style.WindowBorderSize = 0.0f;
    style.FrameBorderSize  = 0.0f;

    style.ScrollbarSize    = 12.0f;
    style.GrabMinSize      = 8.0f;
}