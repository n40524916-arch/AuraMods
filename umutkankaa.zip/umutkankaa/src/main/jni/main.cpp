#include <jni.h>
#include <pthread.h>
#include <android/input.h>
#include <cstdlib>
#include <iostream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <sstream>
#include <iomanip>
#include <cctype>
#include <cstring> 
#include <sstream>
#include <array>
#include <unistd.h>
#include <sys/system_properties.h>//
#include <GLES3/gl3.h>
#include <EGL/egl.h>
#include <vector>

#include "xdl.h"
#include "And64InlineHook/And64InlineHook.hpp"
#include "Include.h"
#include "imgui.h"
#include "imgui_internal.h"
#include "imgui_impl_opengl3.h"
#include "imgui_impl_android.h"
#include "Roboto-Regular.h"
#include "Icon.h"
#include "Iconcpp.h"
#include "Vector3.h"

#include "Il2Cpp/il2cpp_dump.h"

#include "include/Hook/KittyMemory/KittyMemory.h"
#include "include/Hook/KittyMemory/MemoryPatch.h"
#include "include/Hook/KittyMemory/KittyScanner.h"
#include "include/Hook/KittyMemory/KittyUtils.h"

#include "obfuscate.h"
#include "Utils.h"

#include <cfloat>

#include "style.h"
#include "watermark.h"

#include "imgui_touch.hpp"

#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, "modd", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "modd", __VA_ARGS__)


std::vector<MemoryPatch> memoryPatches;
std::vector<uint64_t> offsetVector;

int screenWidth;
int screenHeight;

struct Quaternion {
    float x, y, z, w;
};
bool showMainMenu = true;
bool setup;
using namespace ImGui;

uintptr_t healthOffset = 0;

bool esp = false;

Vector3 (*WorldToScreenPoint)(void* instance, Vector3);
Vector3 (*get_position)(void* instance);
void* (*get_main)();
void* (*get_transform)(void* instance);
void (*Transform_set_position)(void* transform, Vector3 pos);

void* (*old_dlopen)(const char*, int);
bool (*get_isMine)(void *);
void (*_PlayerUpdate)(void* player);
void (*old_Player_OnDestroy)(void* player);

bool EspBox = false;
bool EspLine = false;
bool Esp3DBox = false;
float depthFactor = 0.3f;
bool snapEnabled = false;
bool autoKillEnabled = false;
float teleKillMaxDistance = 50.0f;
float teleportOffsetY = 1.5f;

float boxColor[4] = {1.0f, 1.0f, 1.0f, 1.0f};
float outlineColor[4] = {0.0f, 0.0f, 0.0f, 0.0f};
float lineColor[4] = {1.0f, 1.0f, 1.0f, 1.0f};
float lineThickness = 2.0f;

void* myPlayer = nullptr;
std::vector<void*> players;

bool IsPlayerAlive(void* player) {
    if (!player) return false;
    void* trans = get_transform(player);
    if (!trans) return false;
    float* health = (float*)((uintptr_t)player + healthOffset);
    if (!health) return true;
    return *health > 0.0f;
}

bool playerFind(void* player) {
    for (auto& p : players) {
        if (p == player) return true;
    }
    return false;
}

void PlayerUpdate(void* player) {
    if (player) {
        if (get_isMine(player)) {
            myPlayer = player;
        } else {
            if (!playerFind(player)) {
                players.push_back(player);
            }
        }
    }
    if (_PlayerUpdate) _PlayerUpdate(player);
}

void Player_OnDestroy(void* player) {
    if (player) {
        for (auto it = players.begin(); it != players.end(); ++it) {
            if (*it == player) {
                players.erase(it);
                break;
            }
        }
        if (myPlayer == player) myPlayer = nullptr;
    }
    if (old_Player_OnDestroy) old_Player_OnDestroy(player);
}

void DrawESP(ImDrawList* draw, int screenWidth, int screenHeight) {
    if (!esp) return;
    if (screenWidth == 0 || screenHeight == 0) return;
    if (!get_main || !get_position || !WorldToScreenPoint) return;

    void* camera = get_main();
    if (!camera) return;

    for (int i = 0; i < (int)players.size(); ++i) {
        void* player = players[i];
        if (!player) continue;
        if (!IsPlayerAlive(player)) continue;
        if (player == myPlayer) continue;

        void* transform = get_transform(player);
        if (!transform) continue;

        Vector3 PlayerPos = get_position(transform);
        Vector3 Head = Vector3(PlayerPos.x, PlayerPos.y + 1.6f, PlayerPos.z);
        Vector3 Bottom = Vector3(PlayerPos.x, PlayerPos.y, PlayerPos.z);

        Vector3 HeadPos = WorldToScreenPoint(camera, Head);
        Vector3 BottomPos = WorldToScreenPoint(camera, Bottom);

        if (HeadPos.z < 0.0f || BottomPos.z < 0.0f) continue;

        float boxHeight = fabsf(HeadPos.y - BottomPos.y);
        if (boxHeight < 0.1f) continue;

        float boxWidth = boxHeight * 0.65f;
        float rectX = HeadPos.x - (boxWidth / 2);
        float rectY = screenHeight - HeadPos.y;

        ImVec2 rectMin = ImVec2(rectX, rectY);
        ImVec2 rectMax = ImVec2(rectX + boxWidth, rectY + boxHeight);

        ImU32 boxColorU32 = ImGui::GetColorU32(ImVec4(boxColor[0], boxColor[1], boxColor[2], boxColor[3]));
        ImU32 outlineColorU32 = ImGui::GetColorU32(ImVec4(outlineColor[0], outlineColor[1], outlineColor[2], outlineColor[3]));
        ImU32 lineColorU32 = ImGui::GetColorU32(ImVec4(lineColor[0], lineColor[1], lineColor[2], lineColor[3]));

        if (EspBox) {
            draw->AddRect(rectMin, rectMax, boxColorU32, 0.0f, 14, 1.5f);
        }

        if (EspLine) {
            draw->AddLine(ImVec2(screenWidth / 2, 0),
                          ImVec2(HeadPos.x, screenHeight - HeadPos.y),
                          lineColorU32, lineThickness);
        }

        if (Esp3DBox) {
            float depth = boxWidth * depthFactor;
            float offsetX = depth * 0.5f;
            float offsetY = depth * 0.25f;

            ImVec2 frontTL = rectMin;
            ImVec2 frontTR = ImVec2(rectMin.x + boxWidth, rectMin.y);
            ImVec2 frontBL = ImVec2(rectMin.x, rectMin.y + boxHeight);
            ImVec2 frontBR = ImVec2(rectMin.x + boxWidth, rectMin.y + boxHeight);

            ImVec2 backTL = ImVec2(rectMin.x - offsetX, rectMin.y - offsetY);
            ImVec2 backTR = ImVec2(rectMin.x + boxWidth - offsetX, rectMin.y - offsetY);
            ImVec2 backBL = ImVec2(rectMin.x - offsetX, rectMin.y + boxHeight - offsetY);
            ImVec2 backBR = ImVec2(rectMin.x + boxWidth - offsetX, rectMin.y + boxHeight - offsetY);

            draw->AddLine(frontTL, frontTR, boxColorU32, 1.5f);
            draw->AddLine(frontTR, frontBR, boxColorU32, 1.5f);
            draw->AddLine(frontBR, frontBL, boxColorU32, 1.5f);
            draw->AddLine(frontBL, frontTL, boxColorU32, 1.5f);

            draw->AddLine(backTL, backTR, boxColorU32, 1.5f);
            draw->AddLine(backTR, backBR, boxColorU32, 1.5f);
            draw->AddLine(backBR, backBL, boxColorU32, 1.5f);
            draw->AddLine(backBL, backTL, boxColorU32, 1.5f);

            draw->AddLine(frontTL, backTL, boxColorU32, 1.5f);
            draw->AddLine(frontTR, backTR, boxColorU32, 1.5f);
            draw->AddLine(frontBL, backBL, boxColorU32, 1.5f);
            draw->AddLine(frontBR, backBR, boxColorU32, 1.5f);
        }
    }
}




float menuScale = 1.1f;

void DrawMenu() {
    const ImVec2 window_size = ImVec2(700, 500);
    ImGui::SetNextWindowSize(window_size, ImGuiCond_Always);

    // Turuncu tema — referans: UdawzDLC menüsü
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding,   8.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding,    6.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowTitleAlign, ImVec2(0.5f, 0.5f));
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing,      ImVec2(4.0f, 2.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,    ImVec2(4.0f, 4.0f));

    ImGui::PushStyleColor(ImGuiCol_TitleBg,         ImVec4(0.72f, 0.40f, 0.05f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_TitleBgActive,   ImVec4(0.72f, 0.40f, 0.05f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_WindowBg,        ImVec4(0.05f, 0.05f, 0.05f, 0.98f));
    ImGui::PushStyleColor(ImGuiCol_Border,          ImVec4(0.0f,  0.0f,  0.0f,  0.0f));
    ImGui::PushStyleColor(ImGuiCol_CheckMark,       ImVec4(1.0f,  1.0f,  1.0f,  1.0f));
    ImGui::PushStyleColor(ImGuiCol_FrameBg,         ImVec4(0.50f, 0.27f, 0.03f, 0.60f));
    ImGui::PushStyleColor(ImGuiCol_FrameBgHovered,  ImVec4(0.72f, 0.40f, 0.05f, 0.70f));
    ImGui::PushStyleColor(ImGuiCol_FrameBgActive,   ImVec4(0.72f, 0.40f, 0.05f, 0.90f));
    ImGui::PushStyleColor(ImGuiCol_Header,          ImVec4(0.60f, 0.33f, 0.04f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_HeaderHovered,   ImVec4(0.72f, 0.40f, 0.05f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_HeaderActive,    ImVec4(0.55f, 0.30f, 0.03f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_SliderGrab,      ImVec4(0.90f, 0.55f, 0.10f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_SliderGrabActive,ImVec4(1.0f,  0.65f, 0.15f, 1.0f));

    ImGui::Begin("UdawzCheats.t.me", nullptr, ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoResize);

    if (ImGui::CollapsingHeader("Visuals")) {
        ImGui::Checkbox("ESP Enable",    &esp);
        ImGui::Checkbox("ESP Line",      &EspLine);
        ImGui::Checkbox("ESP Box",       &EspBox);
        ImGui::SliderFloat("Line Thickness", &lineThickness, 1.0f, 5.0f, "%.1f");
    }

    ImGui::End();

    ImGui::PopStyleColor(13);
    ImGui::PopStyleVar(6);
}


static int screen_width = 1220;
static int screen_height = 2712;

int get_width() { return screen_width; }
int get_height() { return screen_height; }

void SetupImgui() {
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ApplyPurpleTheme();   
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2(
        screenWidth > 0 ? (float)screenWidth : 1920.0f,
        screenHeight > 0 ? (float)screenHeight : 1080.0f
    );
 //   ImGui_ImplAndroid_Init(io);

    ImGuiStyle *style = &ImGui::GetStyle();
    style->Alpha = 1.0f;
    style->WindowTitleAlign = ImVec2(0.5, 0.5);
    style->PopupRounding = 3;
    style->WindowPadding = ImVec2(8, 8);
    style->FramePadding  = ImVec2(2, 4);
    style->ItemSpacing   = ImVec2(2, 2);
    style->ScrollbarSize = 14;
    ImGui::GetStyle().Colors[ImGuiCol_ScrollbarBg]          = ImVec4(0.08f, 0.08f, 0.08f, 1.0f);
    ImGui::GetStyle().Colors[ImGuiCol_ScrollbarGrab]        = ImVec4(0.22f, 0.22f, 0.22f, 1.0f);
    ImGui::GetStyle().Colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.32f, 0.32f, 0.32f, 1.0f);
    ImGui::GetStyle().Colors[ImGuiCol_ScrollbarGrabActive]  = ImVec4(0.40f, 0.40f, 0.40f, 1.0f);
    style->WindowBorderSize = 1;
    style->ChildBorderSize  = 1;
    style->PopupBorderSize  = 3;
    style->FrameBorderSize  = 1;
    style->WindowRounding    = 3;
    style->ChildRounding     = 3;
    style->FrameRounding     = 3;
    style->ScrollbarRounding = 2;
    style->GrabRounding      = 3;
    ImGui_ImplOpenGL3_Init("#version 100");
    ImFontConfig font_cfg;
    io.Fonts->AddFontFromMemoryTTF(&Roboto_Regular, sizeof(Roboto_Regular), 28.0, &font_cfg, io.Fonts->GetGlyphRangesCyrillic());
    ImGui::GetStyle().ScaleAllSizes(2.0f);
}

// EGL, ANativeWindow

std::string GetProp(const char* key) {
    char value[PROP_VALUE_MAX];
    __system_property_get(key, value);
    return std::string(value);
}

bool clearMousePos = true;
struct UnityEngine_Vector2_Fields {
    float x;
    float y;
};
struct UnityEngine_Vector2_o {
    UnityEngine_Vector2_Fields fields;
};
enum TouchPhase {
    Began = 0,
    Moved = 1,
    Stationary = 2,
    Ended = 3,
    Canceled = 4
};
struct UnityEngine_Touch_Fields {
    int32_t m_FingerId;
    struct UnityEngine_Vector2_o m_Position;
    struct UnityEngine_Vector2_o m_RawPosition;
    struct UnityEngine_Vector2_o m_PositionDelta;
    float m_TimeDelta;
    int32_t m_TapCount;
    int32_t m_Phase;
    int32_t m_Type;
    float m_Pressure;
    float m_maximumPossiblePressure;
    float m_Radius;
    float m_fRadiusVariance;
    float m_AltitudeAngle;
    float m_AzimuthAngle;
};

EGLBoolean (*old_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface);
EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
    static bool is_setup = false;
    if (!is_setup) {
        SetupImgui();
        is_setup = true;
    }

    // Ambil dimensi via eglQuerySurface — lebih reliable dari ANativeWindow hooks
    EGLint egl_w = 0, egl_h = 0;
    eglQuerySurface(dpy, surface, EGL_WIDTH,  &egl_w);
    eglQuerySurface(dpy, surface, EGL_HEIGHT, &egl_h);
    if (egl_w > 0 && egl_h > 0) {
        screenWidth  = egl_w;
        screenHeight = egl_h;
    }

    ImGuiIO &io = ImGui::GetIO();

    if (screenWidth > 0 && screenHeight > 0) {
        io.DisplaySize = ImVec2((float)screenWidth, (float)screenHeight);
    }

    ImGui::GetIO().FontGlobalScale = menuScale;
    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();

    DrawESP(ImGui::GetBackgroundDrawList(), screenWidth, screenHeight);
    DrawWatermark();
    DrawMenu();

    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    ImGui::EndFrame();

/*  if (should_clear_mouse_pos) {
        io.MousePos = ImVec2(-1, -1);
        should_clear_mouse_pos = false;
    }*/
    return old_eglSwapBuffers(dpy, surface);
}

void *imgui_go(void*) {
    void *handle_egl = xdl_open("libEGL.so", XDL_DEFAULT);
    void *xdl_sym_egl = xdl_sym(handle_egl, "eglSwapBuffers", nullptr);
    A64HookFunction(xdl_sym_egl, (void*)hook_eglSwapBuffers, (void**)&old_eglSwapBuffers);
    // ANativeWindow_getWidth/Height hooks dihapus — dimensi diambil dari eglQuerySurface di hook_eglSwapBuffers

    pthread_exit(nullptr);
}

void* Dlopen(const char* filename, int flags) {
    if (strstr(filename, "libvulkan.so")) {
        return nullptr;
    }
    return old_dlopen(filename, flags);
}

void *hack_thread(void*) {
    while (dlopen("libEGL.so", 4) == nullptr) sleep(1);

    void* libc = dlopen("libc.so", RTLD_NOW);
    A64HookFunction(dlsym(libc, "dlopen"), (void*)Dlopen, (void**)&old_dlopen);

    do { sleep(1); } while (!isLibraryLoaded("libil2cpp.so"));
    
    
    //public sealed class Camera : Behaviour ->
    //public Vector3 WorldToScreenPoint(Vector3 position) { } 
WorldToScreenPoint = (Vector3(*)(void*, Vector3)) getAbsoluteAddress("libil2cpp.so", 0xC64D51C);
    //public class Transform : Component, IEnumerable -> 
    //public Vector3 get_position() { }
    get_position = (Vector3 (*)(void *)) getAbsoluteAddress("libil2cpp.so", 0xC6E2914);
    //public class Component : Object ->
    //public Transform get_transform() { }
    get_transform = (void *(*)(void*)) getAbsoluteAddress("libil2cpp.so", 0xC6C920C);
    //public sealed class Camera : Behaviour ->
    //public static Camera get_main() { }
    get_main = (void*(*)()) getAbsoluteAddress("libil2cpp.so", 0xC64DFC8);
    //public abstract class NetworkBehaviour : MonoBehaviour ->
    //public bool get_isLocalPlayer() { }
    get_isMine = (bool(*)(void *)) getAbsoluteAddress("libil2cpp.so", 0xBB0B880);

       
    //public class PlayerManager : PlayerBehaviour ->
    //private void Update() { }
    A64HookFunction((void*)getAbsoluteAddress("libil2cpp.so", 0x660E668), (void*)PlayerUpdate, (void**)&_PlayerUpdate);
    //public class PlayerManager : PlayerBehaviour ->
    //private void OnDisable() { }
    A64HookFunction((void*)getAbsoluteAddress("libil2cpp.so", 0x6610FC0), (void*)Player_OnDestroy, (void**)&old_Player_OnDestroy);

    if (!touch::InstallHooks()) {
        LOGE("touch::InstallHooks failed — continuing without touch hook");
    }

    Il2CppAttach("libil2cpp.so");
    sleep(5);

    return nullptr;
}

__attribute__((constructor))
void lib_main() {
    pthread_t hacks;
    pthread_create(&hacks, NULL, imgui_go, NULL);
    pthread_create(&hacks, NULL, hack_thread, NULL);
}

extern "C" jint JNIEXPORT JNI_OnLoad(JavaVM *vm, void *key) {
    jvm = vm;
    JNIEnv *env;
    vm->GetEnv((void**)&env, JNI_VERSION_1_6);
    return JNI_VERSION_1_6;
}